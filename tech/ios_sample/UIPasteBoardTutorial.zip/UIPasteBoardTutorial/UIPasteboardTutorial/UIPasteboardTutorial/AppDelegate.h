//
//  AppDelegate.h
//  UIPasteboardTutorial
//
//  Created by KH1386 on 11/12/13.
//  Copyright (c) 2013 KH1386. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
