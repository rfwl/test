//
//  KeyboardFramework.h
//  KeyboardFramework
//
//  Created by Alexei Baboulevitch on 10/23/14.
//  Copyright (c) 2014 Alexei Baboulevitch ("Archagon"). All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for KeyboardFramework.
FOUNDATION_EXPORT double KeyboardFrameworkVersionNumber;

//! Project version string for KeyboardFramework.
FOUNDATION_EXPORT const unsigned char KeyboardFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KeyboardFramework/PublicHeader.h>
#import <KeyboardFramework/UIImage+ImageEffects.h>

